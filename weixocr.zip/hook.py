# hook_print_reg_diag.py
import frida
import sys
import time
import os
import threading
import queue
import time
import json
import re
import base64
from urllib.parse import unquote, unquote_plus
from urllib.parse import urlparse, parse_qs, parse_qsl
hook_chan = queue.Queue()
# -------- 用户配置 --------
process_name = "Weixin.exe"   # 也可以填 PID (int)

search_data = {}
def make_js():
    with open("hook.new.js", "r", encoding="utf-8") as f:
        content = f.read()
        return content
basic_url_pattern = r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?'
url_regex = re.compile(basic_url_pattern)
def on_message(message, data):
    if message['type'] == 'send':
        payload = message['payload']
        if payload['type'] == "svc_data":
            s = payload['str']
            # s = s.replace("\\\n","")
            # s = s.replace("\\\\","")
            try:
                s= json.loads(s)
                s2 = json.loads(s['__params']['jsapi_resp']['resp_json'])
                s3 = json.loads(s2['Json'])
                # print("JSON data",s2['Json'][:10])
                hook_chan.put({'type': 'svc_data','data':s3})
                # 处理数据
                with open("aab1.json", 'w', encoding='utf-8') as f:
                    json.dump(s3, f, ensure_ascii=False, indent=4)
            except Exception as e:
                print(e)
            # s['__params']['jsapi_resp']['resp_json'] = json.loads(s['__params']['jsapi_resp']['resp_json'])
            # print("[svc_data]" , s)
            # with open("aa.json", 'w', encoding='utf-8') as f:
            #     json.dump(s, f, ensure_ascii=False, indent=4)
        if payload['type'] == "key_base":
            s = payload['str']
            decoded_bytes_from_bytes = base64.b64decode(s)
            decoded_string_from_bytes = decoded_bytes_from_bytes.decode('utf-8',errors='ignore')
            # print(decoded_string_from_bytes)
            match = url_regex.search(decoded_string_from_bytes)
            if match:
                found_url = match.group() # group() 返回整个匹配的字符串
                parsed_encoded = urlparse(found_url)
                decoded_params = parse_qs(parsed_encoded.query)
                print(decoded_params)
                if decoded_params.get('key'):
                    print("[key_base]" , decoded_params['uin'][0] , decoded_params['key'][0])
                    hook_chan.put({'type': 'key_base', 'uin': decoded_params['uin'][0],"key": decoded_params['key'][0]})
                # 都不用反编译 直接请求然后获取返回值
                
        if payload['type'] == "open_wxapp":
            if payload['str'].find('gh_') != -1:
                match = re.search(r'wx[a-zA-Z0-9]+', payload['str'])
                if match:
                    wxapp = match.group()
                    match2 = re.search(r'gh_[a-zA-Z0-9]+', payload['str'])
                    if match2:
                        gh_id = match2.group()
                        hook_chan.put({'type': 'open_wxapp', 'appid': wxapp,"gh_id":gh_id})
        # if payload['type'] == 'wxid': # 获取微信号
        #     print("get user wxid: ", payload['str'])
        #     if __name__ != '__main__':
        #         hook_chan.put({'type': 'wxid', 'str': payload['str']})     
        #     with open("wxid.txt", "w", encoding="utf-8") as f:
        #         f.write(payload['str'])
        # if payload['type'] == 'mojo_msg':
        #     # print("get mojo_msg: ", payload['str'])
        #     if payload['str'].find('openWeApp') != -1:
        #         match = re.search(r'wx[a-zA-Z0-9]+', payload['str'])
        #         if match:
        #             wxapp = match.group()
        #             # print("send msg" , payload['str'])
        #             if __name__ != '__main__':
        #                 hook_chan.put({'type': 'open_wxapp', 'str': wxapp})     

        # if payload['type'] == 'xlog':
        #     # print(payload['str'])
        #     if payload['str'].find('app_card_list') != -1 or (payload['str'].find('cache_seconds') != -1 and payload['str'].find('session_id') != -1):
        #         # 真正的返回数据
        #         data = json.loads(payload['str'])
        #         data['data'] = json.loads(data['data'])
        #         if payload['str'].find('app_card_list') == -1:
        #             data['data']['app_card_list'] = []
        #         # print(data['data'])
        #         if __name__ != '__main__':
        #             hook_chan.put({'type': 'getsearchapp', 'data': data['data']})     
            # else:
                # print("[xlog]" , payload['str'])
import psutil               

def find_and_attach_to_weixin():
    """
    查找并 attach 到父进程不是 Weixin.exe 的 Weixin.exe 实例。
    """
    try:
        # 1. 获取所有运行的进程
        # 注意：frida.enumerate_processes() 也可以用，但 psutil.process_iter() 更直接用于获取详细信息
        weixin_processes = []
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'].lower() == 'weixin.exe': # 注意大小写不敏感比较
                weixin_processes.append(proc.info['pid'])

        if not weixin_processes:
            print("未找到任何 Weixin.exe 进程。")
            return None

        target_pid = None
        # 2. 检查每个 Weixin.exe 进程的父进程
        for pid in weixin_processes:
            try:
                p = psutil.Process(pid)
                parent = p.parent() # 获取父进程对象

                # 3. 判断父进程是否存在且其名称不是 Weixin.exe
                if parent is not None:
                    parent_name = parent.name().lower()
                    print(f"Weixin.exe (PID: {pid}) 的父进程是: {parent_name} (PID: {parent.pid})")
                    if parent_name != 'weixin.exe':
                        print(f"找到目标进程: Weixin.exe (PID: {pid}), 其父进程是 {parent_name}")
                        target_pid = pid
                        break # 找到第一个符合条件的就停止
                else:
                    # 如果父进程不存在（可能已退出），也可以考虑 attach
                    print(f"Weixin.exe (PID: {pid}) 的父进程不存在 (可能已退出)，暂时不选择。")
                    target_pid = pid
                    break
                    # 如果你希望 attach 到父进程不存在的实例，可以在这里赋值 target_pid = pid 并 break
            except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                 # 如果在检查过程中进程消失或无权限访问父进程信息
                print(f"检查进程 PID {pid} 时出错: {e}")

        # 4. 如果找到了目标 PID，则 attach
        if target_pid is not None:
            print(f"正在 attach 到 PID {target_pid}...")
            session = frida.attach(target_pid)
            return session,target_pid
        else:
            print("未找到父进程不是 Weixin.exe 的 Weixin.exe 实例。")
            return None

    except Exception as e:
        print(f"发生错误: {e}")
        return None
           
def HookWeixin():
    js = make_js()
    pid = 0
    try:
        session,pid = find_and_attach_to_weixin()
        # session = frida.attach(process_name) if not (isinstance(process_name, int) or str(process_name).isdigit()) else frida.attach(int(process_name))
    except Exception as e:
        print("attach failed:", e)
        try:
            pid = frida.spawn([process_name])
            session = frida.attach(pid)
            frida.resume(pid)
        except Exception as e2:
            print("spawn failed:", e2)
            return

    script = session.create_script(js)
    script.on('message', on_message)
    script.load()
    # if data is bytes/bytearray, convert to list of ints for JS
    # 优先使用同步 API
    try:
        script.exports_sync.start()
    except AttributeError:
        try:
            script.exports.start()
        except Exception:
            pass
    except Exception:
        pass

    print("Listening... press Ctrl+C to quit.")
    hook_chan.put({'type': 'start','pid':pid})
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Detaching...")
        session.detach()
        
from difflib import SequenceMatcher

def prefix_ratio(a: str, b: str) -> float:
    n = min(len(a), len(b))
    print("prefix_ratio: ", n)
    return SequenceMatcher(None, a, b).ratio()
import getpass
import pyautogui
if __name__ == '__main__':
    HookWeixin()
    # user = getpass.getuser()
    # print(user)
    # d = {}
    # with open("./a copy 2.json",'r',encoding="utf-8") as f:
    #     data = json.load(f)
    #     data['data'] = json.loads(data['data'])
    #     d = data['data']
    # with open("./a222.json",'w',encoding="utf-8") as f:
    #     json.dump(d,f,ensure_ascii=False,indent=4)
    # ration = prefix_ratio("携程", "携程旅行订酒店机票火车汽车门票")
    # print(ration)

