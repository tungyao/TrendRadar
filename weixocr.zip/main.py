# from ocr import OCR
import psutil
import time
import win32gui
import win32process
import win32con
import win32ui
from PIL import Image
import ctypes
import uuid
from ctypes import wintypes
import win32api
import subprocess
import os
import pyautogui
from PIL import Image, ImageTk
import tkinter as tk
import numpy as np
import pyperclip
import subprocess
import getpass
import json
from ocr import OcrHandle
from pathlib import Path
ocr = OcrHandle()
user = getpass.getuser()
user32 = ctypes.windll.user32
ctx = {"ready":False,"pid":None,"wxid": None,'wechat_hwnd':None,
       'weixin_hwnd':None,'ex_pid':None,'this_uid':None,'is_flush':True,'first':False,'search_num':0,
       'search_name':None,'search_com':None,'search_com_step':None,'search_com_data':None,'search_com_can_recv':False,
       'open_wxapp': {'wxid':None,'name':None,'gh_id':None}}
keybase = {"uin":None,"key":None,"last_time":None}
all_company = set()
PUL = ctypes.POINTER(ctypes.c_ulong)

def ensure_key_first(original_dict, first_key):
  """
  创建一个新字典，确保指定的 key 在第一个位置。
  如果该 key 不存在于原字典中，则不会被添加到结果中。
  """
  if not isinstance(original_dict, dict):
      raise TypeError("Input must be a dictionary")

  new_dict = {}
  # 首先处理指定的 key（如果存在）
  if first_key in original_dict:
    new_dict[first_key] = original_dict[first_key]

  # 然后添加其余的键值对
  for key, value in original_dict.items():
    if key != first_key: # 避免重复添加
       new_dict[key] = value

  return new_dict

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort),
        ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", PUL)
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_ulong),
        ("ki", KEYBDINPUT)
    ]
def send_key(vk_code):
    extra = ctypes.c_ulong(0)
    ki = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=0, time=0, dwExtraInfo=ctypes.pointer(extra))
    x = INPUT(type=1, ki=ki)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
    # 释放按键
    ki_up = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=2, time=0, dwExtraInfo=ctypes.pointer(extra))
    x_up = INPUT(type=1, ki=ki_up)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x_up), ctypes.sizeof(x_up))

def send_string(text):
    for c in text:
        vk = ord(c.upper())  # 简单处理 A-Z / 0-9 字符
        send_key(vk)
        time.sleep(0.01)
        
def get_average_pixel_value(image):
    """
    获取图像所有通道中所有像素的平均值，返回一个整数
    """
    np_img = np.array(image, dtype=np.float32)  # 转为浮点方便求平均

    # 如果是灰度图或其他二维数据，直接计算平均
    if np_img.ndim == 2:
        avg_value = np_img.mean()
    else:
        # 多通道图像，通道一起平均
        avg_value = np_img.mean()
    
    return int(avg_value)
def crop_and_show(img, left, top, width, height):
    """
    裁剪指定区域并弹窗显示裁剪后的图片，同时显示裁剪位置
    重庆医科大学附属儿童医院
    参数:
        image_path: 图片路径
        left, top: 裁剪区域左上角坐标
        width, height: 裁剪区域宽高
    """
    # 打开图片
    
    # 计算右下角
    right, bottom = left + width, top + height
    cropped_img = img.crop((left, top, right, bottom))
    root = tk.Tk()
    root.title(f"裁剪区域: 左上({left},{top}) 右下({right},{bottom})")
    tk_img = ImageTk.PhotoImage(cropped_img)
    label = tk.Label(root, image=tk_img)
    label.pack()
    root.mainloop()
    
    # 返回裁剪后的PIL图片对象，方便后续操作
    return cropped_img
def find_wxapp_windows(class_name="Chrome_WidgetWin_0",title_name = "微信"):
    windows = []
    time.sleep(1)
    def enum_windows_callback(hwnd, _):
        # 获取窗口所属进程 PID
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        if pid == ctx["ex_pid"]:
            cname = win32gui.GetClassName(hwnd)
            title = win32gui.GetWindowText(hwnd)
            if class_name == cname and  title != title_name and win32gui.IsWindowVisible(hwnd):
                windows.append(title)

    win32gui.EnumWindows(enum_windows_callback, None)
    return windows
def find_wechat_window(class_name="Chrome_WidgetWin_0", title_keyword="微信"):
    """Find a window by class and title keyword"""
    target_hwnd = None

    def enum_callback(hwnd, _):
        global ctx
        nonlocal target_hwnd
        try:
            if hwnd:
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                if win32gui.GetClassName(hwnd) == class_name:
                    title = win32gui.GetWindowText(hwnd)
                    if title_keyword == title:
                        target_hwnd = hwnd
                        ctx["ex_pid"] = pid
                        return False  # Stop enumeration
        except Exception as e:
            print(f"Error in enum_callback:",e)
        return True

    try:
        win32gui.EnumWindows(enum_callback, None)
    except Exception as e:
        print(f"Error in find_wechat_window:",e)
    return target_hwnd



def find_wechat_path():
    """
    遍历所有进程，找到 WeChat.exe 的路径
    """
    for proc in psutil.process_iter(['name', 'exe']):
        try:
            if proc.info['name'] and proc.info['name'].lower() == "weixin.exe":
                return proc.info['exe']
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return None
def reopen_wechat():
    wechat_path = find_wechat_path()
    if not wechat_path or not os.path.exists(wechat_path):
        print("未找到微信进程或路径")
        return False

    # 使用 /reopen 参数唤起微信窗口
    subprocess.Popen([wechat_path, "/reopen"])
    print("已尝试唤起微信窗口")
    return True
# pid = 0
def find_weixin_window(class_name="Qt51514QWindowIcon", args=None):
    """Find Weixin.exe process and return its main window handle"""
    print("args" , args)
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == 'Weixin.exe':
            pid = ctx['pid']
            print("Found Weixin.exe process with PID:", pid)
            hwnds = []

            def callback(hwnd, hwnds):
                try:
                    _, window_pid = win32process.GetWindowThreadProcessId(hwnd)
                    if window_pid == pid:  # 仅处理当前进程的窗口
                        title = win32gui.GetClassName(hwnd)
                        if title == class_name and win32gui.IsWindowVisible(hwnd): # WeChatMainWndForPC WeChatLoginWndForPC
                            print("1 Found window:", win32gui.IsIconic(hwnd))
                            if win32gui.IsIconic(hwnd):
                                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                            # ctypes.windll.user32.SetForegroundWindow(hwnd)
                            hwnds.append(hwnd)
                            print("2 Found window:", title)
                            # activate_window(hwnd)
                    # if window_pid == pid and win32gui.IsWindowVisible(hwnd) and win32gui.GetWindow(hwnd, win32con.GW_OWNER) == 0:
                    #     print("Found window:", title)
                    #     activate_window(hwnd)
                except(e):
                    print(e)
                    pass
                return True  # ✅ 不要中断，避免 pywin32 抛错
            
            try:
                print("Checking process PID:", pid)
                win32gui.EnumWindows(callback, hwnds)
            except Exception as e:
                print("EnumWindows failed:", e)

            if hwnds:
                # 如果想返回主窗口，通常是第一个pip install Pillowpip install Pillowpip install Pillow
                return hwnds[0]
    return None

def resize_window(hwnd,x= 0 ,y = 100,width=800, height=700):
    """Resize Weixin window to 800x700"""
    if not hwnd:
        hwnd = find_weixin_window()
    if hwnd:
        # Set window size to 800x700
        win32gui.SetWindowPos(hwnd, win32con.HWND_TOP, x, y, width, height, 
                             win32con.SWP_SHOWWINDOW)
        return True
    return False

def screenshot_window(hwnd):
    # 获取窗口位置
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width = right - left
    height = bottom - top
    save_name  = uuid.uuid4()
    save_path = f"temp/{save_name}.png"
    save_bmp =  f"temp/{save_name}.bmp"
    # 获取窗口设备上下文（DC）
    hwndDC = win32gui.GetWindowDC(hwnd)
    mfcDC = win32ui.CreateDCFromHandle(hwndDC)
    saveDC = mfcDC.CreateCompatibleDC()
    # 创建位图对象
    saveBitMap = win32ui.CreateBitmap()
    saveBitMap.CreateCompatibleBitmap(mfcDC, width, height)

    # 将窗口内容复制到位图
    saveDC.SelectObject(saveBitMap)
    saveDC.BitBlt((0, 0), (width, height), mfcDC, (0, 0), win32con.SRCCOPY)

    # 保存截图为 BMP 再转 PNG
    saveBitMap.SaveBitmapFile(saveDC, save_bmp)
    img = Image.open(save_bmp)
    img.save(save_path, 'PNG')

    # ✅ 释放顺序非常重要
    saveDC.DeleteDC()                         # 删除兼容DC
    win32gui.ReleaseDC(hwnd, hwndDC)         # 释放窗口DC
    win32gui.DeleteObject(saveBitMap.GetHandle())  # 删除位图对象

    print(f"截图已保存到: {save_path}")
    return img
def screenshot_window_ex(hwnd):
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width = right - left
    height = bottom - top
    save_name  = f"{uuid.uuid4()}"
    save_path = f"temp/{save_name}.png"
    save_bmp =  f"temp/{save_name}.bmp"
    # print(save_bmp)
    hwndDC = win32gui.GetWindowDC(hwnd)
    mfcDC = win32ui.CreateDCFromHandle(hwndDC)
    saveDC = mfcDC.CreateCompatibleDC()
    saveBitMap = win32ui.CreateBitmap()
    saveBitMap.CreateCompatibleBitmap(mfcDC, width, height)
    saveDC.SelectObject(saveBitMap)

    # 使用 ctypes 调用 PrintWindow
    PW_RENDERFULLCONTENT = 0x00000002  # 尝试完整渲染
    ctypes.windll.user32.PrintWindow(hwnd, saveDC.GetSafeHdc(), PW_RENDERFULLCONTENT)
    bmpinfo = saveBitMap.GetInfo()
    bmpstr = saveBitMap.GetBitmapBits(True)
    img = Image.frombuffer('RGBA', (bmpinfo['bmWidth'], bmpinfo['bmHeight']), bmpstr, 'raw', 'BGRA', 0, 1)
    img = img.convert('RGB')
    # img.save(save_path)
    # saveBitMap.SaveBitmapFile(saveDC, save_bmp)
    # saveBitMap.SaveBitmapFile(saveDC, "temp.bmp")
    # img = Image.open(save_bmp)
    # img.save(save_path, 'PNG')
    # 清理
    win32gui.DeleteObject(saveBitMap.GetHandle())
    saveDC.DeleteDC()
    mfcDC.DeleteDC()
    win32gui.ReleaseDC(hwnd, hwndDC)
    return save_name,img
def window_exists(class_name = "Chrome_WidgetWin_0", window_text= "微信"):
    hwnd = win32gui.FindWindow(class_name, window_text)
    return hwnd != 0  # 返回 True/False

def find_main_window(pid):
    """根据 PID 找到主窗口句柄"""
    hwnd_found = []

    def enum_windows(hwnd, lParam):
        _, window_pid = win32process.GetWindowThreadProcessId(hwnd)
        if window_pid == pid and win32gui.IsWindowVisible(hwnd) and win32gui.GetWindow(hwnd, win32con.GW_OWNER) == 0:
            hwnd_found.append(hwnd)
            return False  # 找到主窗口停止枚举
        return True

    win32gui.EnumWindows(enum_windows, None)
    if hwnd_found:
        return hwnd_found[0]
    return None

def input_text(text):
    pyperclip.copy(text)
    pyautogui.hotkey('ctrl', 'v')
    pyautogui.press("enter")

def activate_window(hwnd):
    """激活窗口到前台"""
    if not hwnd:
        return False
    print("Activating window...")
    foreground_hwnd = win32gui.GetForegroundWindow()
    fg_thread = user32.GetWindowThreadProcessId(foreground_hwnd, 0)
    target_thread = user32.GetWindowThreadProcessId(hwnd, 0)

    # 如果不是同一个线程，需要附加输入
    user32.AttachThreadInput(target_thread, fg_thread, True)

    # 显示窗口并置前
    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
    user32.SetForegroundWindow(hwnd)
    user32.SetFocus(hwnd)
    user32.SetActiveWindow(hwnd)

    user32.AttachThreadInput(target_thread, fg_thread, False)
    return True

def doClick(x,y):
    print("正在点击:",x,y)
    pyautogui.moveTo(x,y, duration=0.2)  # 移动到指定位置
    pyautogui.click(x,y)
    time.sleep(0.1)
def doWeixin():
    global ctx
    while True:
            hwnd = find_weixin_window()
            if hwnd:
                win32gui.SetForegroundWindow(hwnd)
                resize_window(hwnd)
                ctx['weixin_hwnd'] = hwnd
                break
            else:
                status = reopen_wechat()
                if status:
                    time.sleep(0.5)
                    hwnd = find_weixin_window()
                    win32gui.SetForegroundWindow(hwnd)
                    if hwnd:
                        resize_window(hwnd)
                        ctx['weixin_hwnd'] = hwnd
                        break
                    else:
                        print("❌ 微信窗口未找到, 打开微信")
                        time.sleep(2)
                else:
                    time.sleep(2)
    px = 30
    py = 436
    doClick(px,py)
    # print("重新打开了搜索页面")
    return True
def doWechat(wechat_hwnd):
    win32gui.ShowWindow(wechat_hwnd, win32con.SW_RESTORE)
    win32api.keybd_event(0,0,0,0)  # 模拟用户输入
    time.sleep(0.1)
    win32gui.SetForegroundWindow(wechat_hwnd)
    resize_window(wechat_hwnd,800,100,623)
    rect = win32gui.GetWindowRect(wechat_hwnd)  # (left, top, right, bottom)
    left, top, right, bottom = rect
    width = right - left
    height = bottom - top
    print(f"✅ HWND: {wechat_hwnd}")
    print(f"📍 窗口位置: Left={left}, Top={top}, Right={right}, Bottom={bottom}")
    print(f"📐 尺寸: {width} x {height}")
    # 验证这玩意是不是白色的 用于首次打开的时候 出现白屏的情况
    img_name,img = screenshot_window_ex(wechat_hwnd)
    img  = np.array(img)
    color = get_average_pixel_value(img)
    print(f"✅ 颜色: {color}")
    if color == 245:
        doWeixin()
        return False
    return True    
    
# 新增一个方法用来点击到匹配的坐标
def doClickTo(wechat_hwnd,x,y):
    # 计算xy的坐标
    pyautogui.moveTo(x,y, duration=0.2)  # 移动到指定位置
    pyautogui.click(x,y)
    time.sleep(0.1)
# def doOcr(img_name):
#     res = OCR( "temp/"+img_name+".png")
#     # print(res)
#     print("✅ 识别结果:")
#     if res:
#         print(res[0])
first  = 0  # 是否进行了第一次搜索

    
import threading
import queue
import time

msg_chan = queue.Queue()
from flask import Flask, request, jsonify
app = Flask(__name__)

status_data = {}

@app.route('/search', methods=['POST'])
def handle_post():
    global status_data
    data = request.get_json()  # 自动解析 JSON
    print("Received JSON:", data)
    uid = uuid.uuid4()
    msg_chan.put({"text":data['text'],"id":uid})
    ctx['search_name'] = data['text']
    status_data[uid] = "wait"
    print("新增任务",uid, data['text'])
    return jsonify({"status": "ok", "received": data,'uid': uid})
@app.route('/status/<id>')
def handle_status(id):
    print(status_data)
    return jsonify({"status": status_data[id]})

def screenshotSearch(wechat_hwnd):
    img_name,img = screenshot_window_ex(wechat_hwnd)
    left = 106
    top = 140
    width = 623 - left -50
    height = 20
    search_box = crop_and_show(img, left, top, width, height)
    return img_name,search_box
def screenshotSearchEx(wechat_hwnd):
    img_name,img = screenshot_window_ex(wechat_hwnd)
    left = 106
    top = 150
    width = 623 - left -50
    height = 20
    search_box = crop_and_show(img, left, top, width, height)
    return img_name,search_box
def screenshotIsNone(wechat_hwnd):
    img_name,img = screenshot_window_ex(wechat_hwnd)
    left = 290
    top = 400
    width = 40
    height = 14
    search_box = crop_and_show(img, left, top, width, height)
    return search_box

def screenReconnect(wechat_hwnd):
    img_name,img = screenshot_window_ex(wechat_hwnd)
    left = 280
    top = 440
    width = 80
    height = 20
    search_box = crop_and_show(img, left, top, width, height)
    return search_box
def screenshotIsWait(wechat_hwnd):
    img_name,img = screenshot_window_ex(wechat_hwnd)
    left = 290
    top = 380
    width = 40
    height = 30
    search_box = crop_and_show(img, left, top, width, height)
    return search_box
none_shot = np.load("none_shot.npy")
reconn_shot = np.load("reconn_shot.npy")
wait_shot = np.load("wait_shot.npy")
def doSearch(wechat_hwnd,search_btn,text):
    win32gui.SetForegroundWindow(wechat_hwnd)
    doClick(search_btn[0],search_btn[1])
    pyperclip.copy(text)
    pyautogui.hotkey('ctrl', 'v')
    pyautogui.press("enter")
    time.sleep(0.5)
    doClick(search_btn[0],search_btn[1])
    doClick(search_btn[0]-300,search_btn[1])

    # return
    rec_text = ""
    while True:
        img_name,search_box = screenshotSearch(wechat_hwnd)
        img_nameEx,search_boxEx = screenshotSearchEx(wechat_hwnd)
        # search_box.save(f"temp/{img_name}.png")
        search_box = np.array(search_box)
        search_boxEx = np.array(search_boxEx)
        # 通过颜色来判断是否有结果
        color = get_average_pixel_value(search_box)
        print(f"✅ 颜色: {color}")
        if color == 233: # 多种情况
            pass
        if color  == 237:
            print("正在区分结果")
            box = screenshotIsNone(wechat_hwnd)
            if np.array_equal(box, none_shot):
                print("✅ 搜索结果为空")
                return False
            box = screenReconnect(wechat_hwnd)
            if np.array_equal(box, reconn_shot): # 等待搜索结果
                print("✅ 需要重新点击")
                left, top, right, bottom = win32gui.GetWindowRect(wechat_hwnd)
                doClick(left + 300 , top + 450)
                continue
            print("✅ 需要等待")
            continue
        # res = OCR(f"temp/{img_name}.png")
        res = ocr.text_predict(search_box,320)
        print(res)
        if len(res) > 0:
            tmp_box, count, text2,score = res[0]
            rec_text = text2
            print("✅ OCR: ",rec_text)
            break
        else:
            res = ocr.text_predict(search_boxEx,320)
            if len(res) > 0:
                tmp_box, count, text2,score = res[0]
                rec_text = text2
                print("✅ OCR EX: ",rec_text)
            break
    if rec_text == text:
        # 直接点击
        print("✅ 匹配到字符串: ",rec_text)
        # 返回真的xy地址
        print("鼠标应该移动到: " , 800 + 106 , 100 + 140)
        return [800 + 106 , 100 + 140]
    
    return False
wxapp_path = None
def closewxapp(class_name, title):
    hwnd = win32gui.FindWindow(class_name, title)
    if hwnd:
        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        print(f"窗口已关闭: Class={class_name}, Title={title}")
    else:
        print("未找到匹配的窗口")

from more_step import req_html,html_to_json
# 开始对小程序继续反编译
def decompilerwxapp(wxid,folders):
    global keybase
    global ctx
    global status_data
    for folder in folders:
        if os.path.exists(os.path.join(wxapp_path, folder)):
            html = req_html(wxid,keybase['uin'],keybase['key'])
            print("keybase: ",keybase)
            is_flush = False
            if len(html) < 100:
                #　基本没有返回值
                last_time = keybase['last_time']
                doClick(600,600)
                ti = 0 
                while True:
                    if ti >5:
                        doClick(600,600)
                        ti = -999
                    if last_time != keybase['last_time']:
                        html = req_html(wxid,keybase['uin'],keybase['key'])
                        if len(html) < 100:
                            doClick(600,600)
                            time.sleep(1)
                            continue
                        # 关闭重新打开
                        is_flush = True
                        break
                    time.sleep(1)
                    print("等待key刷新")
                    ti+=1
            json_txt = html_to_json(html)
            # 写入一个appid
            json_txt['appid'] = wxid
            print("json_txt",json_txt)
            print("decompiler", os.path.join(wxapp_path, folder))
            wxid = ctx["open_wxapp"]["wxid"]
            wxname = ctx["open_wxapp"]["name"]
            print("反编译参数",ctx)
            wxpath = os.path.join(wxapp_path, folder)
            print("wxpath",wxpath)
            result = subprocess.run(["./depress.exe", f"-id={wxid}" , f'-in={wxpath}' , f'-out=./depress/{wxid}'], capture_output=True, text=True,encoding="utf-8")
            print(result.stdout)
            
            json_txt = ensure_key_first(json_txt,"appid")
            with open(f"./depress/{wxid}/{wxid}.json", "w", encoding="utf-8") as f:
                json.dump(json_txt, f, ensure_ascii=False, indent=4)
                print("✅ 保存小程序配置文件")
    closewxapp("Chrome_WidgetWin_0",wxname)
    ctx['is_flush'] = is_flush

    # if is_flush:

        
    status_data[ctx['this_uid']] = "done"
    ctx['this_uid'] = None
    
from hook import HookWeixin
from hook import hook_chan
from difflib import SequenceMatcher
def prefix_ratio(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def hook_loop():
    global ctx
    global keybase
    # 接受hook的队列消息
    while True:
        msg = hook_chan.get()
        # print("get msg",msg)
        if msg['type'] == 'start':
            ctx['ready'] = True
            ctx['pid'] = msg['pid']
        if msg['type'] == 'wxid':
            ctx['wxid'] = msg['str']
            print("✅ 获取微信ID: ",ctx['wxid'])
        if msg['type'] == 'getsearchapp':
            data = msg['data']
            ix = 0
            isExist = False
            max_ratio = 0
            for item in data['app_card_list']:
                if ix > 5: # 只判断前五个就行了
                    status_data[ctx['this_uid']] = "done-none"
                    break
                if item['app_nick_name'].find(ctx['search_name']) != -1: # 完全匹配
                    isExist = True
                    xy = [800 + 106 , 100 + 140 + (ix * 116)]
                    max_ratio = 100
                    break
                if prefix_ratio(item['app_nick_name'],ctx['search_name']) >  0.6: # 这个阈值可以调整
                    isExist = True
                    xy = [800 + 106 , 100 + 140 + (ix * 116)]
                    if max_ratio !=100:
                        max_ratio = 10
                    
                ix += 1
            if  isExist == False:
                status_data[ctx['this_uid']] = "done-none"
            if max_ratio !=0:
                time.sleep(2)
                xy = [800 + 106 , 100 + 140 + (ix * 116)]
                doClick(xy[0],xy[1])
            else:
                status_data[ctx['this_uid']] = "done-none"
                
        if msg['type'] == 'open_wxapp':
            ctx['open_wxapp']['wxid'] = msg['appid']
            ctx['open_wxapp']['gh_id'] = msg['gh_id']
            app = find_wxapp_windows()
            print(app)
            if len(app) > 0:
                ctx['open_wxapp']['name'] = app[0]
                appid = msg['appid']
                # wxid = ctx["open_wxapp"]["wxid"]
                global wxapp_path
                # wxapp_path = f'C:\\Users\\{user}\\Documents\\WeChat Files\\Applet\\{wxid}'
                wxapp_path = f'C:\\Users\\{user}\\AppData\\Roaming\\Tencent\\xwechat\\radium\\Applet\\packages\\{appid}'
                if os.path.exists(wxapp_path):
                    print("✅ 找到小程序目录", wxapp_path)
                    # 继续往下面走一个阶段
                    folders = [f for f in os.listdir(wxapp_path) if os.path.isdir(os.path.join(wxapp_path, f))]
                    print("✅ 找到小程序目录下的文件夹: ", folders)
                    threading.Thread(target=decompilerwxapp, args=(msg['appid'], folders)).start()
                    # decompilerwxapp(msg['appid'],folders)
                 
        if msg['type'] == 'key_base':
            print("✅ 获取密钥成功")
            keybase['key'] = msg['key']
            keybase["uin"] = msg['uin']
            keybase['last_time'] = time.time()
        if msg['type'] == 'svc_data': # 这个消息会推送两次 第一次是公众号 第二次是 服务号
            print("获取到搜索数据, 正在进行比对")
            data = msg['data']
            if ctx['search_com_can_recv'] != True:
                print("跳过接受数据")
                continue
            if ctx['search_com_data'] !=None:
                ctx['search_com_step'] = 2
            else:
                ctx['search_com_step'] = 1
            # for item in data['data'][0]['subBoxes']:
            #     if len(item['items'] ) > 0:
            #         one = item['items'][0]
            #         if one.get('source',None) == None:
            #             continue
            #         print("正在比对",one['source']['title'],ctx['search_com'])
            #         if one['source']['title'] == ctx['search_com']: # 这玩意只有一个
            #             print("✅ 找到公众号",one['source']['title'])
            #             # 看菜单里面有没有链接
            #             menu = one.get('menus',[])
            #             print(menu)
            #             for menuitem in menu:
            #                 if menuitem['jumpInfo']['jumpType'] == 3:
            #                     # 区分搜索进行到了第几部
            #                     if ctx['search_com_data'] != None:
            #                         ctx['search_com_data']['data'].append(menuitem)
            #                         ctx['search_com_step'] = 2
            #                     else:
            #                         ctx['search_com_data'] = {'data':[],'name':ctx['search_com']}
            #                         ctx['search_com_data']['data'].append(menuitem)
            #                         ctx['search_com_step'] = 1
            os.makedirs("./company", exist_ok=True)
            # if ctx['search_com_step'] == 2 and ctx['search_com_data']!=None:
            if Path(f"./company/{ctx['search_com']}.json").is_file():
                # with open(f"./company/{ctx['search_com']}_{ctx['search_num']}.json",'r',encoding='utf-8') as f:
                #     cd = json.load(f)
                #     # 合并两个data
                #     for sitem in ctx['search_com_data']['data']:
                #         # 需要去重
                #         is_add = True
                #         for citem in cd['data']:
                #             if citem['jumpInfo']['jumpUrl'] == sitem['jumpInfo']['jumpUrl']:
                #                 is_add = False
                #                 break
                #         if is_add:
                #             cd['data'].append(sitem)
                            
                with open(f"./company/{ctx['search_com']}_{ctx['search_num']}.json",'w',encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=4)
            else:
                with open(f"./company/{ctx['search_com']}_{ctx['search_num']}.json",'w',encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=4)
                    print("✅ 保存公司网站文件",ctx['search_com_data'])
            ctx['search_com_step'] = 3         
            
                        
                    
isLogin = False               

def init():
    # 扫描小程序目录
    # 等待微信代开
    if find_wechat_path() == None:
        print("🙏 等待微信启动")
        subprocess.Popen(["C:\\Program Files\\Tencent\\Weixin\\Weixin.exe"])
    while True:
        print("🔍 搜索微信窗口")
        if find_wechat_path():
            break
        time.sleep(1)
    print("💬 微信已启动, 正在进行hook")
    # threading.Thread(target=HookWeixin, daemon=True).start()
    global isLogin
    
    # 通过判断微信窗口大小进行判断
    hwnd = find_weixin_window("Chrome_WidgetWin_0")
    if hwnd:
        isLogin == False
    else:
        try:
            with open("wxid.txt", "r", encoding="utf-8") as f:
                wxid = f.read()
                if wxid == "":
                    isLogin == False
                    print("⚠️ 未找到微信ID, 等待自动获取")
                else:
                    isLogin = True
                    
                    print("✅ 找到微信ID: ", wxid)
                    ctx['wxid'] = wxid
        except FileNotFoundError:
            with open("wxid.txt", "w") as f:
                f.write("")
                isLogin == False
    if isLogin  == False:
        print("⚠️ 未登录微信, 请登录")
        isLogin == False
    while True:
        if isLogin == True:
            break
        # msg  = hook_chan.get()
        # if msg['type'] == 'wxid':
        #     ctx['wxid'] = msg['str']
        #     print("✅ 找到微信ID: ", msg['str'])
        #     isLogin = True
        # time.sleep(1)

            
    threading.Thread(target=hook_loop, daemon=True).start() 

def init_new():
    
    while True:
        hwnd = find_wechat_window()

        if hwnd:
            print("找到微信wechat窗口")
            return True
        else:
            print("⚠️ 未找到搜索窗口, 尝试打开")
            doWechat()
    # hwnd = find_wxapp_windows("Chrome_WidgetWin_0")
    
    

# 对于新增加的步骤 用来指定第一次打开搜索框的时候
def more_step_first(text):
    global ctx
    # 重新打开了wxappex需要程序执行那个框
    if ctx['is_flush'] == True or ctx['first'] == True:
        doClick(128,144) # 点击那个搜索框
        pyperclip.copy('a')
        pyautogui.hotkey('ctrl', 'v')
        pyautogui.press("backspace")
        time.sleep(0.5)
        doClick(143,196) # 点击那个搜索框
        time.sleep(0.5)
        doClick(1136,405) # 公众号那个按钮
        time.sleep(0.5)
        doClick(900,362) # 那个搜索框
        time.sleep(0.1)
        if ctx['first']:
            ctx['first'] = False
    else:
        doClick(1000,186) # 那个搜索框
    ctx['search_num'] = 1
    ctx['search_com_can_recv'] = True
    input_text(text)
    time.sleep(4)
    doClick(1095,278) # 服务号那个按钮
    ctx['search_num'] = 2
    time.sleep(4)




def main():
    # init()
    # is_open = init_new()
    is_open = False
    global status_data
    global ctx
    global all_company
    
    threading.Thread(target=HookWeixin, daemon=True).start()
    threading.Thread(target=hook_loop, daemon=True).start()
    while True:
        if ctx['ready'] == True:
            print("✅ 微信已就绪")
            break
    print("is open",is_open)
    while True:
        if is_open == False:
            try:
                doWeixin()
            except:
                print("实例化微信窗口失败, 正在重试")
                time.sleep(2)
                continue
        
        time.sleep(2)
        while True:
            wechat_hwnd = find_wechat_window(class_name="Chrome_WidgetWin_0", title_keyword="微信")
            if wechat_hwnd:
                break
        if wechat_hwnd:
            ctx['wechat_hwnd'] = wechat_hwnd
            if doWechat(wechat_hwnd):
                # exit(0)
                left, top, right, bottom = win32gui.GetWindowRect(wechat_hwnd)
                search_btn  = [left+595,top+70]

                # while True:
                #     time.sleep(1)
                # 等待小程序启动
                # while True:
                #     app = find_wxapp_windows(title_name="title_name")
                #     if app:
                #         global wxapp_path
                #         wxapp_path = f'C:\\Users\\{user}\\AppData\\Roaming\\Tencent\\xwechat\\radium\\Applet\\packages'
                #         if os.path.exists(wxapp_path):
                #             print("✅ 找到小程序目录", wxapp_path)
                #             folders = [f for f in os.listdir(wxapp_path) if os.path.isdir(os.path.join(wxapp_path, f))]
                #             # C:\Users\Administrator\AppData\Roaming\Tencent\xwechat\radium\Applet\packages
                #             decompilerwxapp(folders)
                # return
                # print(search_btn)
                # return
                # search_box = screenshotSearch(wechat_hwnd)
                # search_box = np.array(search_box)
                # avg_color = get_average_pixel_value(search_box)
                # print(avg_color)
                # box = screenshotIsWait(wechat_hwnd)
                # box_r = np.load("wait_shot.npy")
                # if np.array_equal(box, box_r):
                #     print("✅ 等待搜索结果")
                #     time.sleep(5)
                    
                # 最好将np输出到缓存 方便下次直接比对
                # color = get_average_pixel_value(box)
                # print(color)
                 
                # 处理是否有搜索框
                # search_box.save("temp/"+img_name+"_search.png")
                # doOcr(img_name)
                # 移动到搜索框
                # 输入文本
                # return
                # first  = 1
                # global status_data
                # global ctx
                # while True:
                #     if ctx['ready'] == True:
                #         break
                with open("demo.txt","r",encoding="utf-8") as f:
                    for line in f.readlines():
                        l = line.split()
                        print(l)
                        ctx['search_name'] = l[1]
                        ctx['search_com'] = l[0]
                        title_name = l[1]
                        save_name  = f"{uuid.uuid4()}"
                        item = {"text":title_name,"id": save_name}
                        print(item)
                        status_data[save_name] =  "wait"
                        ctx['this_uid'] = save_name
                        doClick(1078,120)
                        mouse_will_move = doSearch(ctx['wechat_hwnd'],search_btn,title_name)
                        if mouse_will_move:
                            doClick(mouse_will_move[0],mouse_will_move[1])
                            while True:
                                print("等待搜索结果",status_data[save_name])
                                if status_data[save_name] == "done":
                     
                                    break
                                time.sleep(1)

                            # doClick(324,24) # 鼠标移动到小程序的搜索框
                            # 将那个东西移动到
                             
                        else:
                            print("没找到这个小程序")
                            with open("demo-not-find.txt","a",encoding="utf-8") as f:
                                f.write(line)
                                f.write("\n")
                        
                        print("搜索公众号",ctx['search_com'])
                        print(ctx['search_com'], all_company)
                        if (ctx['search_com'] in all_company):
                            print("找到这个公众号,进行跳过")
                            ctx['search_com_step'] = 0
                            ctx['search_com_can_recv'] = False
                            ctx['search_com'] = ''
                            ctx['search_com_data'] = None
                            # doClick(324,24) # 鼠标移动到小程序的搜索框
                            continue
                        more_step_first(ctx['search_com'])
                        
                        while True:
                            doClick(1160,115)
                            print("进行搜索公众号和服务号的操作",'step: ',ctx['search_com_step'])
                            if ctx['search_com_step'] == 3:
                                ctx['search_com_can_recv'] = False
                                all_company.add(ctx['search_com'])
                                break
                            time.sleep(1)
                        print("is_flush",ctx['is_flush'])
                        if ctx['is_flush'] :
                            ctx['first'] = True
                            print("需要关闭ex窗口")
                            closewxapp("Chrome_WidgetWin_0","微信")
                            doWeixin()
                            time.sleep(1)
                            wechat_hwnd = False
                            while True:
                                try:
                                    wechat_hwnd = find_wechat_window(class_name="Chrome_WidgetWin_0", title_keyword="微信")
                                except Exception as e:
                                    print("ex窗口查找失败,正在重试")
                                    print(e)
                                if wechat_hwnd:
                                    break
                                time.sleep(1)
                            ctx['wechat_hwnd'] = wechat_hwnd
                            print("find hwnd ",wechat_hwnd)
                            doWechat(ctx['wechat_hwnd'])
                        # 清除本次的存放的临时数据
                        ctx['search_com_step'] = 0
                        ctx['search_com_can_recv'] = False
                        ctx['search_com'] = ''
                        ctx['search_com_data'] = None
                # while True:
                #     item = msg_chan.get()  # 阻塞直到有元素
                #     print(item)
                #     status_data[save_name] =  "wait"
                #     ctx['this_uid'] = save_name
                #     mouse_will_move = doSearch(ctx['wechat_hwnd'],search_btn,title_name)
                #     if mouse_will_move:
                #         doClick(mouse_will_move[0],mouse_will_move[1])
                #         while True:
                #             print("等待搜索结果",status_data[save_name])
                #             if status_data[save_name] == "done":
                #                 break
                #             time.sleep(1)
                #     else:
                #         print("没找到这个小程序")
                #         with open("demo-not-find.txt","a",encoding="utf-8") as f:
                #             f.write(line)
                #             f.write("\n")
                break
if __name__ == '__main__':
    # print(none_shot)
    
    main()
    # doClick(128,144)
    # ctx['is_flush'] = False
    # more_step_first('雪场')
    # wechat_hwnd = find_wechat_window(class_name="Chrome_WidgetWin_0", title_keyword="微信")
    # box = screenReconnect(wechat_hwnd)
    # box.save("none_shot.npy")
    # box = np.asarray(box)
    # np.save('reconn_shot.npy', box)
    # print(box)
    # if np.array_equal(box, reconn_shot):
        # print("✅ 搜索结果为空")
# threading.Thread(target=main, daemon=True).start()
# app.run(host='0.0.0.0', port=5000)

    