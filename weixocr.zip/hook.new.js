// hook_use_ptr_readCString.js
// 使用 ptr.readCString()（在你的环境可用）来读取 C 字符串
// 并在拦截时可选地 dump ctx 前若干字节
function send_info(k, v) { send({ type: 'info', key: k, val: String(v) }); }
function hex(p) { try { return ptr(p).toString(); } catch (e) { return String(p); } }

// ---------- 配置 ----------
var module_name = "Weixin.dll";     // 模块名（按需修改）
var target_rva = 0x37BC300;            // 目标函数 RVA（按需修改）
var svc_rva = 0x2CC487;
var dump_ctx_bytes = true;             // 是否打印 ctx 前 N 字节（十六进制）
var dump_ctx_bytes_len = 64;           // 打印长度
var auto_invoke_fake_ctx = false;      // 是否自动伪造 ctx 并调用（危险，慎用）
// --------------------------------

var key_rva = 0x14CFF3C;

// ---------- 读取函数选择（优先 ptr.readCString） ----------
var can_ptr_read = (typeof NativePointer.prototype.readCString === 'function');
function readUtf8Ptr(ptr) {
    if (ptr.isNull && ptr.isNull()) return null;
    try {
        if (can_ptr_read) return ptr.readCString();
    } catch (e) {
        // failover to manual
    }
    // Manual fallback (simple)
    var out = [];
    var off = 0;
    while (true) {
        try {
            var b = Memory.readU8(ptr.add(off));
        } catch (e) { break; }
        if (b === 0) break;
        out.push(b);
        off++;
        if (off > 10 * 1024 * 1024) break;
    }
    // Use simple TextDecoder if available
    if (typeof TextDecoder !== 'undefined') {
        return (new TextDecoder('utf-8')).decode(new Uint8Array(out));
    }
    var s = "";
    for (var i = 0; i < out.length; i++) s += String.fromCharCode(out[i]);
    return s;
}
// --------------------------------

// ---------- find module & func ----------
var mod = Process.findModuleByName(module_name);
var wmpf_host_export_x64 = Process.findModuleByName('wmpf_host_export_x64.dll');
if (!mod) {
    console.log("Module not found:", module_name);
    Process.enumerateModulesSync().slice(0, 30).forEach(function(m,i){
        console.log(i, m.name, m.base);
    });
}
var funcAddr;
var keyAddr;
var svcAddr; // 新增加的服务号和公众号的链接的查询
try { funcAddr = mod.base.add(ptr(target_rva)); } catch (e) { funcAddr = ptr(mod.base).add(ptr(target_rva)); }
try { keyAddr = mod.base.add(ptr(key_rva)); } catch (e) { keyAddr = ptr(mod.base).add(ptr(key_rva)); }
try { svcAddr = wmpf_host_export_x64.base.add(ptr(svc_rva)); } catch (e) { svcAddr = ptr(wmpf_host_export_x64.base).add(ptr(svc_rva)); }
console.log("[*] module:", module_name, " base:", mod.base, " funcAddr:", funcAddr," keyAddr:",keyAddr);
console.log("[*] using ptr.readCString? ", can_ptr_read);

// ---------- attach interceptor to inspect ctx ----------
Interceptor.attach(funcAddr, {
    onEnter: function (args) {
        var val = this.context.rbx;
        console.log("val:", val);
        if (val){
            var p_addr = val.readPointer();
            console.log("p_addr:", p_addr);
            if(p_addr){
                var s = p_addr.readUtf8String();
                console.log(s);
                send({ type: 'open_wxapp', title: "open_wxapp", str: s, ptr: p_addr.toString() });
            }
    
        }
        
        
    },
    onLeave: function (retval) {
        // try { console.log("open wxapp return:", retval); } catch (e) {}
    }
});
Interceptor.attach(keyAddr, {
    onEnter: function (args) {
        var val = this.context.rcx;
        console.log("val:", val);
        if (val){
            var p_addr = val.readPointer();
            console.log("p_addr:", p_addr);
            if(p_addr){
                var s = p_addr.readUtf8String();
                // console.log(s);
                send({ type: 'key_base', title: "key_base", str: s, ptr: p_addr.toString() });
            }
    
        }
        
        
    },
    onLeave: function (retval) {
        // try { console.log("open wxapp return:", retval); } catch (e) {}
    }
});

Interceptor.attach(svcAddr, {
    onEnter: function (args) {
        // console.log("\n[Hook] Target function called!");
        // console.log("[Hook] Function Address: 0x" + funcAddr.toString(16));
        // console.log("[Hook] Hooked at: 0x" + this.returnAddress.toString(16)); // 调用者地址，有助于确认是否是你要的调用点
        try {
            // const esp = this.context.rcx; // 这是 push ebx 之前的 esp 值
            // const src = this.context.rdx;
            // const dst = this.context.rcx;
            const src = this.context.rdx;
            const len = this.context.r8.toUInt32(); // 字节长度（注意：若是 UTF-16 要除以2）
            const shadow = Memory.alloc(len);
            try {
                Memory.copy(shadow, src, len);
            } catch (e) {
                console.log("[safeRead] Memory.copy error:", e.message);
            }
            try {
                // 先读取几个字符 用来判断是否是需要的字符
                var short_str = shadow.readUtf8String(185);
                if (short_str == '{"__callback_id":"1000","__msg_type":"callback","__params":{"base_resp":{"error_msg":"type:0, code:0, msg:","ret":0},"err_msg":"H5ExtTransfer:ok","jsapi_resp":{"error_msg":"","resp_json'){
                    var str = shadow.readUtf8String(len);
                    // console.log("[safeRead] str:", str);
                    send({ type: 'svc_data', str: str });
                }
                // 这玩意会被调用两次 其中一次是有完整数据的

            } catch (error) {
                // console.log("[safeRead] readUtf8String error:", error.message);
            }
        } catch (e) {
            console.error("[Hook] Error reading parameters from stack via ebx:", e.message);
            console.error(e.stack);
        }
    },
    onLeave: function (retval) {
        // try { console.log("xweb_call return:", retval.toInt32()); } catch (e) {}
    }
});

console.log("[*] Hook loaded. dump_ctx_bytes:", dump_ctx_bytes, " auto_invoke_fake_ctx:", auto_invoke_fake_ctx);
