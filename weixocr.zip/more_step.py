# 多加一步操作 获取这个小程序的更多资料的操作
import re
import json
import requests
import base64


# def reget_key():
    
def req_html(appid,uin,key):
    # get请求
    print("req html: ",appid,uin,key)
    if uin == "" or key == "" or appid == "" or key==None or appid == None:
        return ""
    raw = base64.b64decode(uin).decode('utf-8')
    url = f'https://mp.weixin.qq.com/wxawap/waverifyinfo?action=get&appid={appid}&uin={uin}&key={key}&devicetype=UnifiedPCWindows&vers_'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Cookie': f'wxuin={raw}; devicetype=UnifiedPCWindows; version=; lang=; wap_sid2=COHhpogJEnZ5X0hFeFZDUkplLWJVXzJZMFEzbmsxMHJZdG5oaVlZdkdRazYyWUpWNHBkUnZxTmNXM0lGWTlNNUx2aXdmNXg2amxwXzdyVXpkYVFSM25GZFRKeUsyWXE5UU5SVUNYeWt0N1NOcjFxXzNhWGJvcklSTUFBQX5+MKbby8gGOAxAlE4='
    }
    response = requests.get(url,headers=headers)
    response.encoding = response.apparent_encoding
    html = response.text
    print(response.headers)
    return html

def html_to_json(html):
    pattern = r"window\.cgiData\s*=\s*({[^;]+});"
    html  = html.replace("*1","")
    html  = html.replace("* 1","")
    html  = html.replace("'","\"")
    html  = html.replace('wxaproduct_frequency_limit: "",',"")
    match = re.search(pattern, html, re.DOTALL)
    
    if match:
        json_like_str = match.group(1)
        fixed_str = re.sub(r'([{,])\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*:', r'\1 "\2":', json_like_str)
        fixed_str = re.sub(r',(\s*[}\]])', r'\1', fixed_str)
        data = json.loads(fixed_str)
        return data
    return False

# 就要分为两个步骤了

def search_svc(company_name):
    pass



if __name__ == '__main__':
    html = req_html("wxb8f178972cf20c5f","MjQzMzMzMTQyNQ==","daf9bdc5abc4e8d060fc942f67cbdb6133270ddb9cc3041204d8b0bc5a5ec9a7f53994805419553a7ba59af9ca679f743885c2ec1d027ff6c4b018b998e29471e870ec721e45ee0822e3a91a4b866065ac8669d5fdd8f8d921f284c240d848dfe8d7b908ec97445b79b636584baaf0c0238828e3dd1b0bf74051f624d408d49c")
    print(html)